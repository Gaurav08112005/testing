import csv
import os.path
import time
from pyrogram import Client

# Read API credentials from config file
with open('config.ini') as f:
    config = f.read().splitlines()

api_id = int(config[0].split('=')[1].strip())
api_hash = config[1].split('=')[1].strip()

# Create a session folder if it doesn't already exist
if not os.path.exists('sessions'):
    os.makedirs('sessions')

# Load phone numbers from csv file
with open('phone.csv') as f:
    phones = f.read().splitlines()

# Load group information from csv files
group_files = os.listdir('members')
group_info = {}
for filename in group_files:
    with open(f"members/{filename}") as f:
        reader = csv.reader(f)
        rows = list(reader)
        group_info[filename] = {
            'id': rows[0][0],
            'members': rows[1:],
        }

for phone_number in phones:
    # Log in and save the session file
    session_name = f'sessions/{phone_number}'
    with Client(session_name, api_id, api_hash) as client:
        client.start()
        print(f"Session file saved for {phone_number} in {session_name}")

        # Check if there are multiple groups
        if len(group_info) == 1:
            group_name = list(group_info.keys())[0]
        else:
            print("Select a group to send messages to:")
            for idx, group_name in enumerate(group_info.keys()):
                print(f"{idx+1}. {group_name}")
            choice = int(input("Enter your choice: "))
            group_name = list(group_info.keys())[choice-1]
        group_id = group_info[group_name]['id']
        members = group_info[group_name]['members']

        # Read messages to send from file
        with open('messages.txt') as f:
            messages = f.read().splitlines()

        # Send messages to group members
        for member in members:
            user_id = int(member[0])
            username = member[1]

            for message in messages:
                try:
                    client.send_message(user_id, message)
                    print(f"Message sent to {username} from {phone_number}")
                    time.sleep(5)  # wait for 5 seconds before sending next message
                except Exception as e:
                    print(f"Error sending message to {username} from {phone_number}: {str(e)}")

    print(f"Messages sent from {phone_number}. Moving on to the next account...")
